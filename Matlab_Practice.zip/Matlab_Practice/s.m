function s(x , y , z)

% total = x + y + z;
v = [x y z];

% fprintf('%d\n' , total)

fprintf('You elemnets are: ');

for(i = 1 : 1 : 3)
    
    fprintf('%d ' , v(i))
    
end

fprintf('\n');

% Bubble sort

for(i = 1: 1 : 3)
    
    for(j = i + 1 : 1 : 3)
    
    
        if(v(i) > v(j))
            
            tmp = v(i);
            v(i) = v(j);
            v(j) = tmp;
        
        end
        
    end
    
end

fprintf('After Sorting: ');

for(i = 1: 1 : 3)
   
    fprintf('%d ' , v(i))
    
end

fprintf('\n');

end