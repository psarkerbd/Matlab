function [sum , mul , avg , maxi , div , sub] = fun(x , y , z , a , b , c)

    function sum = add(x , y , z , a , b , c)
    
    sum = x + y + z + a + b + c;
    end

    function mul = gun(x , y , z , a , b , c)
    
    mul = x * y * z * a * b * c;
    
    end

    function avg = evarage(x , y , z , a , b , c)
    
        sum = add(x , y , z , a , b , c);
        avg = sum / 6;
    
    end
    
        function [maxi , div , sub] = minus(x , y , z , a , b , c)
        
        v = [x , y , z , a , b , c];
        
        for(i = 1 : 1 : 6)
            
            for(j = i + 1 : 1 : 6)
            
            if(v(i) > v(j))
                
                tmp = v(i);
                
                v(i) = v(j);
                v(j) = tmp;
           
            end
                
            end
            
            
        end
        
        % end
        
        maxi = v(6);
        %div = v(6) / v(1);
        %sub = v(6) - v(1);
        %fprintf('v(6) = %d\n' , v(6))
        %fprintf('v(1) = %d\n' , v(1))
        div = v(6);
        sub = v(6);
        
        for(i = 5 : -1 : 1)
            div = div / v(i);
            sub = sub - v(i);
        end
        
    end

sum = add(x , y , z , a , b , c);
mul = gun(x , y , z , a , b , c);
avg = evarage(x , y , z , a , b , c);
% avg = sum / 6;

[maxi , div , sub] = minus(x , y , z , a , b , c);

end

